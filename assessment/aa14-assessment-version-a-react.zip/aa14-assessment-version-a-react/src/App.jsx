import cats from './mockData/cats.json';
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import Navigation from './components/Navigation'
import CatsIndex from './components/CatsIndex'
import CatShow from './components/CatShow'
import CatForm from './components/CatForm'
import PhotoShow from './components/PhotoShow'
import TogglePhotoType from './components/TogglePhotoType'

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: (
        <>
          <Navigation />
          <CatsIndex cats={cats}/>
        </>
      )
    },
    {
      path: '/cats/:catId',
      element: (
        <>
          <Navigation />
          <CatShow cats={cats}/>
        </>
      )
    },
    {
      path: '/cats/new',
      element: (
        <>
          <Navigation />
          <CatForm />
        </>
      )
    },
    {
      path: '/photo',
      element: (
        <>
          <Navigation />
          <PhotoShow />
        </>
      )
    },
    {
      path: '/toggle-photo-type',
      element: (
        <>
          <Navigation />
          <TogglePhotoType />
        </>
      )
    },
    {
      path: '*',
      element: (
        <>
          <Navigation />
         <h2>Page Not Found</h2>
        </>
      )
    },
  ])


  return (
    <RouterProvider router={router} />
  );
}

export default App;
