import { useParams } from "react-router-dom";

function CatShow({ cats }) {
  const { catId } = useParams();
  const thisCat = cats.find( (cat) => cat.id === catId )
  // console.log("🚀 ~ CatShow ~ thisCat:", thisCat)


  return(
    <>
      <h2>{thisCat.name}</h2>
      <h2>Color: {thisCat.color}</h2>
      <h2>Age: {thisCat.age}</h2>
    </>
  );
}

export default CatShow;
