import { Link } from "react-router-dom";

function CatsIndex({ cats }) {

  return (
    <>
      <h2>Cats Index</h2>
      <ul>
        {cats.map((cat) => (
          <li>
            <Link to={`/cats/${cat.id}`}>
              {cat.name}
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}

export default CatsIndex;
