import { usePhotoContext } from "../context/PhotoContext"

const PhotoShow = () => {
  const { photoUrl } = usePhotoContext();

  return(
    <div className="photo-show">
      <h2>Photo Show</h2>
      <img src={photoUrl} alt='Photo'></img>

    </div>

    // <></>
  );
}

export default PhotoShow;
