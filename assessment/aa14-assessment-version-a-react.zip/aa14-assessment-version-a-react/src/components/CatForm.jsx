import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const COLORS = [
  "yellow",
  "orange",
  "white",
  "black",
  "brown",
  "gray"
];

function CatForm() {
  const [name, setName] = useState("");
  const [age, setAge] = useState(0);
  const [color, setColor] = useState(COLORS[1]);
  const [validateErrors, setValidateErrors] = useState({});

  const navigate = useNavigate();

  useEffect(() => {
    const errors = {}
    if (!name) errors.name = ('Name field is required')
    if (name.length > 30) errors.name = ("Name must be fewer than 30 characters")
    if (age > 30 || age < 0) errors.age = ("Age must be between 0 and 30")

    setValidateErrors(errors)
  }, [name, age])

  const onSubmit = e => {
    e.preventDefault();

    const catInfo = {
      name,
      age,
      color
    }
    console.log(catInfo)

    setName('');
    setAge(0);
    setColor(COLORS[1]);
    setValidateErrors();
  }


  return (
    <form
      className="cat-form"
      onSubmit={onSubmit}
    >


      <h2>Create a Cat</h2>
      <label>
        Name
        <input
          type="text"
          name="name"
          onChange={(e) => setName(e.target.value)}
          defaultValue={''}
        />
      </label>
      <div
      className="error"
      style={{fontSize: '12px', color: 'red'}}
      >
        {validateErrors.name && `* ${validateErrors.name}`}

      </div>


      <label>
        Select a Color
        <select
        defaultValue={COLORS[1]}
        onChange={(e => setColor(e.target.value))}
        >
          {COLORS.map(color => (
            <option
              key={color}
              value={color}
            >
              {color}
            </option>
          ))}
        </select>
      </label>


      <label>
        Age
        <input
          type="number"
          name="age"
          defaultValue={0}
          onChange={ (e) => setAge(e.target.value)}
        />
      </label>
      <div
      className="error"
      style={{fontSize: '12px', color: 'red'}}
      >
        {validateErrors.age && `* ${validateErrors.age}`}

      </div>


      <button
        type="submit"
        disabled= {Object.keys(validateErrors).length > 0}
        onClick={() => navigate('/')}
      >
        Create Cat
      </button>


    </form>
  );
}

export default CatForm;
