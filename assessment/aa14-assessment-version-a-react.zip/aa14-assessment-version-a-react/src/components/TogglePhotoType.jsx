import { usePhotoContext } from "../context/PhotoContext";

const TogglePhotoType = () => {
  const { photoType, setPhotoType } = usePhotoContext();

  return (
    <div className="toggle-photo-type">

      <h2>Cat or Dog?</h2>


      <label>
        <input
          type="radio"
          value="cat"
          name="photoType"
          onChange={(e) => setPhotoType(e.target.value)}
          checked={photoType === 'cat'}
        />
        Cat
      </label>



      <label>
        <input
          type="radio"
          value="dog"
          name="photoType"
          onChange={(e) => setPhotoType(e.target.value)}
          checked={photoType === 'dog'}

        />
        Dog
      </label>



    </div>
  );
}

export default TogglePhotoType;
