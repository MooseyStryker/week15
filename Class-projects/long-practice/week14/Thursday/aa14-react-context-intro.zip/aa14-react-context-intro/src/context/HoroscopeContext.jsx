import { createContext } from "react";

export const HoroscopeContext = createContext();


